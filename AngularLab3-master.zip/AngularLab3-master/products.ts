export class Products {
    ProductId:number;
    ProductName:string;
    ProductCost:number;
    ProductOnline:boolean;
    ProductCat:string;
    Available:string;
}
